package com.example.opencvkotlin

import android.graphics.drawable.BitmapDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import androidx.databinding.DataBindingUtil
import com.example.opencvkotlin.databinding.ActivityMainBinding
import kotlinx.android.synthetic.main.activity_main.*
import org.opencv.android.Utils
import org.opencv.core.Mat
import java.lang.Math.*
import kotlin.math.pow
import kotlin.math.sqrt
import kotlin.properties.Delegates

class MainActivity : AppCompatActivity() {

    lateinit var binding : ActivityMainBinding
    lateinit var mat: Mat
    var prevDrawLineView: DrawLineView? = null
    lateinit var drawLineView : DrawLineView
    private var sizePerPixel by Delegates.notNull<Double>()
    var fromX : Float = 0f
    var fromY : Float = 0f
    var duX : Float = 0f
    var duY : Float = 0f
    var isDraw = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        var image = (imgView.drawable as BitmapDrawable).bitmap

        mat = Mat()
        Utils.bitmapToMat(image, mat)

        var drawableWidth = imgWidth(mat.nativeObjAddr)
        var rectWidth = findRect(mat.nativeObjAddr)
        sizePerPixel = 5 / rectWidth * (drawableWidth.toFloat() / windowManager.defaultDisplay.width)

        //binding.zoom.setScrollEnabled(false)
       // zoom.setZoomEnabled(false)
        Log.i("width", drawableWidth.toString())
        Log.i("rectwidth", rectWidth.toString())
       // binding.zoom.setHasClickableChildren(true)

        binding.frmWrapper.setOnTouchListener { v, event ->

            Log.i("", "touched")
            when(event.action){
                MotionEvent.ACTION_DOWN -> {
                    fromX = event.x
                    fromY = event.y
                    if(prevDrawLineView != null){
                        binding.drawView.removeView(prevDrawLineView)
                    }
                }


                MotionEvent.ACTION_MOVE -> {
                    duX = event.x
                    duY = event.y
                    if(duX != 0f && duY != 0f){
                        if(prevDrawLineView != null){
                            binding.drawView.removeView(prevDrawLineView)
                        }
                        drawLineView = DrawLineView(this, fromX, fromY, duX, duY)
                        binding.drawView.addView(drawLineView, binding.drawView.layoutParams)
                        prevDrawLineView = drawLineView
//                        fromX = event.x
//                        fromY = event.y
                    }
                }

                MotionEvent.ACTION_UP ->{
                    duX = event.x
                    duY = event.y
                    var length = round(distance(fromX, fromY, duX, duY) * sizePerPixel * 100) / 100.0
                    tvResult.text = "$length CM"
                    Log.i("len", length.toString())
                    Log.i("from", "$fromX     $fromY")
                    Log.i("du", "$duX     $duY")
                }
            }

            v.performClick()
        }
        binding.btn.setOnClickListener{
            if(isDraw){
                isDraw = false
                binding.touchWrapper.setOnTouchListener { v, event ->
                    binding.zoom.onInterceptTouchEvent(event)
                }
                binding.zoom.setZoomEnabled(true)
            }
            else{
                isDraw = true
                binding.zoom.setZoomEnabled(false)
                binding.touchWrapper.setOnTouchListener { v, event ->
                    binding.drawView.onInterceptTouchEvent(event)
                }

            }
        }






    }

    fun distance(fromX : Float, fromY : Float, duX : Float, duY : Float) : Double {
        return sqrt(((round(fromX * 100) / 100.0 - round(duX *100) / 100.0)).pow(2) + (round(fromY * 100) / 100.0 - round(duY * 100) / 100.0).pow(2))
    }


    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    external fun findRect(matAddrInput: Long): Double

    external fun imgWidth(matAddrInput: Long): Int
    external fun imgHeight(matAddrInput: Long): Int

    companion object {

        // Used to load the 'native-lib' library on application startup.
        init {
            System.loadLibrary("native-lib")
        }
    }
}
