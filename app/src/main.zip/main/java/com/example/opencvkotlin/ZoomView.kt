package com.example.opencvkotlin

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import com.otaliastudios.zoom.ZoomLayout

class ZoomView(context: Context, attrs: AttributeSet?, defStyleAttr: Int) :
    ZoomLayout(context, attrs, defStyleAttr) {

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        return super.onTouchEvent(ev)
    }
}