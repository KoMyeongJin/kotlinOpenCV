#include <jni.h>
#include <iostream>
#include <opencv2/opencv.hpp>

using namespace cv;
using namespace std;

extern "C" JNIEXPORT jdouble JNICALL
Java_com_example_opencvkotlin_MainActivity_findRect(
        JNIEnv *env,
        jobject object, jlong mat_addr_input
) {
    Mat &input_image = *(Mat *) mat_addr_input;
    Mat img_gray;
    int rect_width;

    cvtColor(input_image, img_gray, COLOR_BGR2GRAY);

    vector<vector<Point>> contours;

    findContours(img_gray, contours, RETR_LIST, CHAIN_APPROX_SIMPLE);

    vector<Point2f> approx;

    for (size_t i = 0; i < contours.size(); i++) {
        approxPolyDP(Mat(contours[i]), approx, arcLength(Mat(contours[i]), true) * 0.02, true);

        int size = approx.size();

        if (size == 4 && isContourConvex(Mat(approx))) {
            rect_width = abs(approx[1].x - approx[2].x);
            break;
        }
    }

    return static_cast<jdouble>(rect_width);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_example_opencvkotlin_MainActivity_imgWidth(
        JNIEnv *env,
        jobject object, jlong mat_addr_input) {

    Mat &input_img = *(Mat *) mat_addr_input;

    return static_cast<jint>(input_img.cols);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_example_opencvkotlin_MainActivity_imgHeight(
        JNIEnv *env,
        jobject object, jlong mat_addr_input) {

    Mat &input_img = *(Mat *) mat_addr_input;

    return static_cast<jint>(input_img.rows);
}

